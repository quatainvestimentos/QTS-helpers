#!/bin/sh
# Accesstage
# 22/Agosto/2010
# V.4.0.14

#basta setar nodisplay que utilizara o parametro "-sync"
#nodisplay=1
#Para indicar uma determinada versao de java, setar JAVA_HOME
#JAVA_HOME=/usr/lib/jvm/java-6-sun/jre

# $JAVA_HOME = /usr/lib/jvm/default-java
# $JAVA_HOME = /usr/lib/jvm/java-1.11.0-openjdk-amd64
# $JAVA_HOME = /usr/lib/jvm/java-11-openjdk-amd64

if [ -z "$DISPLAY" ] ; then
{
   #Nao estou em ambiente grafico, forcar "-sync"
   nodisplay=1
} else {
   nodisplay=0
} fi

if [ "$1" = "-sync" ] || [ "$1" = "-SYNC" ] || [ "$1" = "-s" ] || [ "$1" = "-S" ] || [ "$nodisplay" -eq 1 ] ; then
{
   SYNC="-sync"
} fi

if [ -n "$JAVA_HOME" ] ; then
{
   export PATH=$JAVA_HOME/bin:$PATH
   export JAVA="$JAVA_HOME/bin/java"
} else {
   JAVA=$(which java)
} fi

if [ -n "$JAVA" ] ; then
{
   if [ -x "$JAVA" ] ; then
   {
      export APUSDIR=$(dirname $0)
      export CLASSPATH=.:$CLASSPATH
      export APUSLIB=$APUSDIR/lib
      cd $APUSDIR
      compliance=0
      CLASSPATH="."
      for jar in $(ls -1 $APUSDIR/lib/*.jar) ; do
      {
         CLASSPATH=$CLASSPATH:$jar
         if [ -w "$jar" ] ; then
         {
            compliance=$(( $compliance + 1 ))
         } else {
            #try to correct
            chmod u+w $jar 2>/dev/null
            result=$?
            if [ "$result" -eq "0" ] ; then
            {
               compliance=$(( $compliance + 1 ))
            } fi
         } fi
      } ; done
      if [ "$compliance" -eq "4" ] ; then
      {
         if [ -s "ApusClient.jar" ] ; then
         {
            $JAVA -cp $CLASSPATH -jar -Xmx128m -Xmx256m ApusClient.jar $SYNC
         } else {
            echo "ApusClient nao se encontra no mesmo diretorio do startApus.sh, favor verificar instalacao."
         } fi
      } else {
         echo "Problemas no permissionamento das bibliotecas, verificar diretorio lib"
      } fi

   } else {
      echo "Arquivo java nao esta com direito de execucao, favor verificar"
   } fi
} else {
   echo "Executavel do java nao encontrado, favor verificar"
} fi
